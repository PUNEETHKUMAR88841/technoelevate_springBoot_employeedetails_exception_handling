package com.te.jwt.exception;

public class EmployeeNotfoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
}
